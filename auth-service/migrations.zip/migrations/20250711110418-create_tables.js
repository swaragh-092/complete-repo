'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('clients', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      client_key: {
        type: Sequelize.STRING(50),
        allowNull: false,
        unique: true,
      },
      client_id: {
        type: Sequelize.STRING(100),
        allowNull: false,
        unique: true,
      },
      client_secret: {
        type: Sequelize.STRING(100),
        allowNull: false,
      },
      callback_url: {
        type: Sequelize.STRING(255),
        allowNull: false,
      },
      requires_tenant: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
      },
      tenant_id: {
        type: Sequelize.STRING(50),
        allowNull: true,
      },
      created_at: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      realm_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'realms',
          key: 'id',
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
      },
      redirect_url: {
        type: Sequelize.STRING(255),
        allowNull: true,
      },
      request_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'client_requests',
          key: 'id',
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      },
      auto_generated: {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
      },
    });

    await queryInterface.createTable('audit_logs', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      org_id: {
        type: Sequelize.STRING(50),
      },
      user_id: {
        type: Sequelize.STRING(50),
      },
      client_id: {
        type: Sequelize.STRING(100),
      },
      action: {
        type: Sequelize.STRING(50),
        allowNull: false,
      },
      details: {
        type: Sequelize.JSONB,
        defaultValue: {},
      },
      created_at: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });

    await queryInterface.createTable('tenant_mappings', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      user_id: {
        type: Sequelize.STRING(50),
        allowNull: false,
      },
      tenant_id: {
        type: Sequelize.STRING(50),
        allowNull: false,
      },
      client_key: {
        type: Sequelize.STRING(50),
      },
      created_at: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });

    // await queryInterface.createTable('user_metadata', {
    //   id: {
    //     type: Sequelize.UUID,
    //     defaultValue: Sequelize.UUIDV4,
    //     primaryKey: true,
    //   },
    //   keycloak_id: {
    //     type: Sequelize.STRING(255),
    //     allowNull: false,
    //     unique: true,
    //   },
    //   org_id: {
    //     type: Sequelize.UUID,
    //     allowNull: false,
    //   },
    //   designation: {
    //     type: Sequelize.STRING(100),
    //   },
    //   department: {
    //     type: Sequelize.STRING(100),
    //   },
    //   avatar_url: {
    //     type: Sequelize.TEXT,
    //   },
    //   mobile: {
    //     type: Sequelize.STRING(20),
    //   },
    //   gender: {
    //     type: Sequelize.STRING(10),
    //   },
    //   is_active: {
    //     type: Sequelize.BOOLEAN,
    //     defaultValue: true,
    //   },
    //   last_login: {
    //     type: Sequelize.DATE,
    //   },
    //   created_at: {
    //     type: Sequelize.DATE,
    //     defaultValue: Sequelize.NOW,
    //   },
    //   updated_at: {
    //     type: Sequelize.DATE,
    //     defaultValue: Sequelize.NOW,
    //   },
    // });

    await queryInterface.addConstraint('tenant_mappings', {
      fields: ['user_id', 'tenant_id', 'client_key'],
      type: 'unique',
      name: 'tenant_mappings_unique',
    });

    await queryInterface.addConstraint('tenant_mappings', {
      fields: ['client_key'],
      type: 'foreign key',
      name: 'fk_tenant_mappings_client_key',
      references: {
        table: 'clients',
        field: 'client_key',
      },
      onDelete: 'CASCADE',
    });

    await queryInterface.addConstraint('tenant_mappings', {
      fields: ['user_id'],
      type: 'foreign key',
      name: 'fk_tenant_mappings_user_id',
      references: {
        table: 'user_metadata',
        field: 'keycloak_id',
      },
      onDelete: 'CASCADE',
    });

    await queryInterface.addIndex('clients', ['client_key', 'realm_id', 'tenant_id']);
    await queryInterface.addIndex('audit_logs', ['org_id', 'user_id', 'client_id', 'action']);
    // await queryInterface.addIndex('user_metadata', ['keycloak_id', 'org_id']);
  },

  down: async (queryInterface) => {
    await queryInterface.dropTable('tenant_mappings');
    // await queryInterface.dropTable('user_metadata');
    await queryInterface.dropTable('audit_logs');
    await queryInterface.dropTable('clients');
  },
};