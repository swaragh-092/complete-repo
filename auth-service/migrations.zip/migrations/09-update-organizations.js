'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('organizations', 'tenant_id', {
      type: Sequelize.STRING(50),
      unique: true,
      allowNull: true
    });

    await queryInterface.addColumn('organizations', 'status', {
      type: Sequelize.ENUM('pending', 'active', 'suspended', 'inactive'),
      defaultValue: 'active',
      allowNull: false
    });

    await queryInterface.addColumn('organizations', 'provisioned', {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
      allowNull: false,
      comment: 'Whether org was created by admin vs self-service'
    });

    await queryInterface.addColumn('organizations', 'settings', {
      type: Sequelize.JSON,
      defaultValue: {},
      allowNull: false,
      comment: 'Organization-specific settings'
    });

    // Add indexes
    await queryInterface.addIndex('organizations', ['tenant_id']);
    await queryInterface.addIndex('organizations', ['status']);
    await queryInterface.addIndex('organizations', ['provisioned']);
  },

  down: async (queryInterface, Sequelize) => {
    // Remove indexes first
    await queryInterface.removeIndex('organizations', ['tenant_id']);
    await queryInterface.removeIndex('organizations', ['status']);
    await queryInterface.removeIndex('organizations', ['provisioned']);

    // Remove columns
    await queryInterface.removeColumn('organizations', 'tenant_id');
    await queryInterface.removeColumn('organizations', 'status');
    await queryInterface.removeColumn('organizations', 'provisioned');
    await queryInterface.removeColumn('organizations', 'settings');

    // Drop ENUM type
    await queryInterface.sequelize.query('DROP TYPE IF EXISTS "enum_organizations_status";');
  }
};
