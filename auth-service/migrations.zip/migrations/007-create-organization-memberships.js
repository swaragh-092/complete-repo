'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('organization_memberships', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.fn('gen_random_uuid'),
        primaryKey: true,
      },
      user_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: { model: 'user_metadata', key: 'id' },
      },
      org_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: { model: 'organizations', key: 'id' },
      },
      role_id: {
        type: Sequelize.UUID,
        allowNull: false,
        references: { model: 'roles', key: 'id' },
      },
      status: {
        type: Sequelize.STRING(20),
        defaultValue: 'active',
        allowNull: false,
      },
    });
    await queryInterface.addConstraint('organization_memberships', {
      fields: ['user_id', 'org_id', 'role_id'],
      type: 'unique',
      name: 'org_memberships_unique'
    });
  },
  down: async (queryInterface) => {
    await queryInterface.dropTable('organization_memberships');
  },
};
