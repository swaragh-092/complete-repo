'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('tenant_mappings', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      user_id: {
        type: Sequelize.STRING(50),
        allowNull: false,
      },
      tenant_id: {
        type: Sequelize.STRING(50),
        allowNull: false,
      },
      client_key: Sequelize.STRING(50),
      created_at: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
    });
    await queryInterface.addConstraint('tenant_mappings', {
      fields: ['user_id', 'tenant_id', 'client_key'],
      type: 'unique',
      name: 'tenant_mappings_unique_combo'
    });
  },
  down: async (queryInterface) => {
    await queryInterface.dropTable('tenant_mappings');
  },
};
