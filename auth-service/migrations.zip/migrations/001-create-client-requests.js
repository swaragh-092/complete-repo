// auth-service/migrations/001-create-client-requests.js
'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('client_requests', {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      name: {
        type: Sequelize.STRING(255),
        allowNull: false,
      },
      client_key: {
        type: Sequelize.STRING(100),
        allowNull: false,
        unique: true,
      },
      redirect_url: {
        type: Sequelize.STRING(500),
        allowNull: false,
      },
      description: Sequelize.TEXT,
      developer_email: Sequelize.STRING(255),
      developer_name: Sequelize.STRING(255),
      status: {
        type: Sequelize.ENUM('pending', 'approved', 'rejected'),
        defaultValue: 'pending',
      },
      requested_at: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      approved_at: Sequelize.DATE,
      approved_by: {
        type: Sequelize.UUID,
        references: {
          model: 'user_metadata',
          key: 'id',
        },
      },
      rejection_reason: Sequelize.TEXT,
      metadata: Sequelize.JSON,
    });
  },

  down: async (queryInterface) => {
    await queryInterface.dropTable('client_requests');
  },
};
